package com.zybooks.fitnessappproject;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * A simple {@link Fragment} subclass.

 * create an instance of this fragment.
 */
public class WeightLog extends Fragment {

    private DatabaseWeightLog dbHelper;
    private TableLayout tableLayout;
    private EditText inputDate, inputWeight;
    private Button btnAdd;

    public WeightLog() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_weight_log, container, false);

        dbHelper = new DatabaseWeightLog(getContext());

        inputDate = view.findViewById(R.id.inputDate);
        inputWeight = view.findViewById(R.id.inputWeight);
        btnAdd = view.findViewById(R.id.btnAddWeight);
        tableLayout = view.findViewById(R.id.tableLayout);

        btnAdd.setOnClickListener(v -> {
            String date = inputDate.getText().toString().trim();
            String weight = inputWeight.getText().toString().trim();
            if (!date.isEmpty() && !weight.isEmpty()) {
                dbHelper.addWeight(date, weight);
                inputDate.setText("");
                inputWeight.setText("");
                loadTableData();
            } else {
                Toast.makeText(getContext(), "Please enter both date and weight", Toast.LENGTH_SHORT).show();
            }
        });

        loadTableData();

        return view;
    }

    private void loadTableData() {
        // Clear all rows except the header
        tableLayout.removeViews(1, tableLayout.getChildCount() - 1);

        Cursor cursor = dbHelper.getAllWeights();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String date = cursor.getString(1);
                String weight = cursor.getString(2);

                TableRow row = new TableRow(getContext());
                row.setLayoutParams(new TableLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));

                TextView tvDate = new TextView(getContext());
                tvDate.setText(date);
                tvDate.setPadding(8, 8, 8, 8);
                row.addView(tvDate);

                TextView tvWeight = new TextView(getContext());
                tvWeight.setText(weight);
                tvWeight.setPadding(8, 8, 8, 8);
                row.addView(tvWeight);

                Button btnDelete = new Button(getContext());
                btnDelete.setText("Delete");
                btnDelete.setOnClickListener(v -> {
                    dbHelper.deleteWeight(id);
                    loadTableData();
                });
                row.addView(btnDelete);

                tableLayout.addView(row);

            } while (cursor.moveToNext());
        }

        cursor.close();
    }