package com.zybooks.fitnessappproject;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class AccountCreation extends AppCompatActivity {

    EditText emailEditText, passwordEditText, confirmPasswordEditText, nameEditText,
            birthdayEditText, startingWeightEditText, goalWeightEditText;
    EditText heightFeetEditText, heightInchesEditText;
    RadioButton maleRadio, femaleRadio;
    Button createButton;

    //DBHelper dbHelper; // Assuming you have a DBHelper class for SQLite

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.account_creation);

        // Init Views
        emailEditText = findViewById(R.id.editTextText);
        passwordEditText = findViewById(R.id.editTextTextPassword);
        confirmPasswordEditText = findViewById(R.id.editTextTextPassword2);
        nameEditText = findViewById(R.id.editTextText3);
        birthdayEditText = findViewById(R.id.editTextDate2);
        startingWeightEditText = findViewById(R.id.editTextNumberDecimal);
        goalWeightEditText = findViewById(R.id.goalWeight);
        heightFeetEditText = findViewById(R.id.editTextNumber);
        heightInchesEditText = findViewById(R.id.heightInches);
        maleRadio = findViewById(R.id.radioButton);
        femaleRadio = findViewById(R.id.radioButton2);
        createButton = findViewById(R.id.button);

        //dbHelper = new DBHelper(this);

        createButton.setOnClickListener(this::onClick);
    }

    private void onClick(View v) {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString();
        String confirmPassword = confirmPasswordEditText.getText().toString();
        String name = nameEditText.getText().toString();
        String birthday = birthdayEditText.getText().toString();
        String startWeight = startingWeightEditText.getText().toString();
        String goalWeight = goalWeightEditText.getText().toString();
        String feet = heightFeetEditText.getText().toString();
        String inches = heightInchesEditText.getText().toString();
        String sex = maleRadio.isChecked() ? "Male" : femaleRadio.isChecked() ? "Female" : "";

        // Simple validation
        if (email.isEmpty() || password.isEmpty() || !password.equals(confirmPassword)) {
            Toast.makeText(this, "Check your input", Toast.LENGTH_SHORT).show();
            return;
        }

        // Insert to DB
        //SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("email", email);
        values.put("password", password);
        values.put("name", name);
        values.put("birthday", birthday);
        values.put("start_weight", startWeight);
        values.put("goal_weight", goalWeight);
        values.put("height_ft", feet);
        values.put("height_in", inches);
        values.put("sex", sex);

        long result = db.insert("users", null, values);
        if (result != -1) {
            Toast.makeText(this, "Account Created!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(AccountCreation.this, LoginPage.class));
            finish();
        } else {
            Toast.makeText(this, "Error creating account", Toast.LENGTH_SHORT).show();
        }
    }
}