package com.zybooks.fitnessappproject;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginPage extends AppCompatActivity {

    EditText emailInput, passwordInput;
    Button continueBtn;

    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page_login);

        emailInput = findViewById(R.id.editTextTextEmailAddress);
        passwordInput = findViewById(R.id.editTextNumberPassword);
        continueBtn = findViewById(R.id.continueBtn);

        db = new DatabaseHelper(this);

        continueBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailInput.getText().toString().trim();
                String password = passwordInput.getText().toString().trim();

                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginPage.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (db.checkUserExists(email)) {
                    // Try to log in
                    if (db.validateLogin(email, password)) {
                        Toast.makeText(LoginPage.this, "Login successful!", Toast.LENGTH_SHORT).show();
                        // You can navigate to another activity here
                    } else {
                        Toast.makeText(LoginPage.this, "Incorrect password", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Register new user
                    boolean inserted = db.insertUser(email, password);
                    if (inserted) {
                        Toast.makeText(LoginPage.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(LoginPage.this, "Error creating account", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}